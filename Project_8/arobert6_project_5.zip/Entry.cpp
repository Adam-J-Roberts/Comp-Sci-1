#include "Entry.h"

Entry::Entry()
{
 //assign id
}
string get_entry()
{

}
